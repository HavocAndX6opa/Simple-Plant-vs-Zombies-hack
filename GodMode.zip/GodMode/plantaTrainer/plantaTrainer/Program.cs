﻿using ImGuiNET;
using ClickableTransparentOverlay;
using Swed32;


namespace plantaTrainer
{

    public class Program : Overlay
    {
        bool unlimitedSuns = false;
        IntPtr moduleBase;
        int sunAddress = 0x1F636;
        Swed swed = new Swed("popcapgame1");

        protected override void Render()
        {
            ImGui.Begin("Plant.lol - Made by Dray5513");
            ImGui.Checkbox("never lose suns",ref unlimitedSuns);
            ImGui.End();
        }

        public void HackLogic()
        {
            moduleBase = swed.GetModuleBase(".exe");

            while (true)
            {
                if (unlimitedSuns)
                {
                    swed.WriteBytes(moduleBase, sunAddress, "90 90 90 90 90 90");
                }
                else
                {
                    swed.WriteBytes(moduleBase, sunAddress, "89 B7 78 55 00 00");
                }
            }
        }

        public static void Main(string[] args)
        {
            Console.WriteLine("Starting hack...");
            Program program = new Program();
            program.Start().Wait();
            Thread hackTread = new Thread(program.HackLogic) { IsBackground = true };
            hackTread.Start();
        }
    }
}

